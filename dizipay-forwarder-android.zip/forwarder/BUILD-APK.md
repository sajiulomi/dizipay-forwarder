# DiziPay Forwarder — GitHub diye APK banano (Android Studio lagbe na)

Ei folder-ta GitHub-e upload korle, GitHub nijei cloud-e APK build kore dibe.
Tomar computer-e kichu install korte hobe na.

## Dhap 1 — GitHub account
- github.com e ekta free account khulo (na thakle). Log in koro.

## Dhap 2 — Notun repository banao
1. Upor-e daan dik-er **+** → **New repository**.
2. Repository name: `dizipay-forwarder` (jekono nam cholbe).
3. **Public** select koro (free-te Actions chole). → **Create repository**.

## Dhap 3 — Ei folder-er sob file upload koro
1. Notun repo page-e: **uploading an existing file** link e click (ba **Add file → Upload files**).
2. Ei zip-ta computer-e **extract** koro. Vitorer **sob file + folder** (`app`, `gradle`, `.github`, `build.gradle`, `settings.gradle`, ... sob) ekসাথে select kore **drag-and-drop** koro upload box-e.
   - **Important:** `.github` folder-ta obosshoi thakte hobe — oitei build instruction ache.
3. Niche **Commit changes** (sobuj button) e click.

## Dhap 4 — Build hoy, apekkha koro (~3-5 min)
1. Repo-r upor-er **Actions** tab e jao.
2. "Build APK" naam-e ekta run cholbe (holud dot = cholche, sobuj ✓ = sesh).
   - Prothom bar jodi "Actions" off thake, "I understand... enable" button e click kore enable koro.
3. Sobuj ✓ asle oi run-e click koro.

## Dhap 5 — APK download
1. Run page-er niche **Artifacts** section-e **`dizipay-forwarder-apk`** dekhbe.
2. Oitate click → ekta zip download hobe → extract → vitore **`app-debug.apk`**.

## Dhap 6 — Android phone-e install
1. APK-ta phone-e pathao (WhatsApp/email/cable).
2. Phone-e kholo → "unknown source theke install" allow koro → **Install**.
3. App kholo → **Webhook URL** paste koro:
   `https://dizicare.site/api/pv-sms.php?owner=dizicare&key=whfee_0ea7e98147c90e0b9cb77ee4`
4. **Save** → SMS permission **Allow** koro.
5. Battery optimization oi app-er jonno **off** koro (Settings → Apps → DiziPay Forwarder → Battery → Unrestricted) — jate background-e kokhono bondho na hoy.

## Byas
Oi phone-e bKash/Nagad SMS asleই server-e chole jabe, order auto-active hobe.
Phone-ta charge-e rekhe internet-e rakho — 24/7 cholbe, iPhone-er moto miss korbe na.
