package site.dizicare.forwarder;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Simple config screen: paste the webhook URL, grant SMS permission, test.
 * After that the app forwards every payment SMS automatically in the background.
 */
public class MainActivity extends AppCompatActivity {

    private EditText urlInput;
    private TextView status;

    @Override
    protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);

        int pad = dp(22);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, dp(40), pad, pad);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("DizicarePay Forwarder");
        title.setTextSize(22);
        title.setTextColor(Color.parseColor("#16161a"));
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Paste your Webhook URL (from your Dizicare dashboard). This phone will auto-forward every payment SMS.");
        sub.setTextColor(Color.parseColor("#6b6b76"));
        sub.setPadding(0, dp(8), 0, dp(20));
        root.addView(sub);

        urlInput = new EditText(this);
        urlInput.setHint("https://dizicare.site/api/pv-sms.php?key=...");
        urlInput.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        urlInput.setSingleLine(true);
        root.addView(urlInput);

        SharedPreferences sp = getSharedPreferences("dz", Context.MODE_PRIVATE);
        urlInput.setText(sp.getString("url", ""));

        Button save = button("Save");
        save.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String u = urlInput.getText().toString().trim();
                getSharedPreferences("dz", Context.MODE_PRIVATE).edit().putString("url", u).apply();
                Toast.makeText(MainActivity.this, "Saved", Toast.LENGTH_SHORT).show();
                refresh();
            }
        });
        root.addView(save);

        Button test = button("Send test to server");
        test.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { sendTest(); }
        });
        root.addView(test);

        status = new TextView(this);
        status.setPadding(0, dp(24), 0, 0);
        status.setTextColor(Color.parseColor("#6b6b76"));
        root.addView(status);

        setContentView(root);

        ensurePermission();
        refresh();
    }

    private Button button(String label) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setTextColor(Color.parseColor("#241a00"));
        btn.setBackgroundColor(Color.parseColor("#F5B811"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(14);
        btn.setLayoutParams(lp);
        return btn;
    }

    private void ensurePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS}, 1);
        }
    }

    private void refresh() {
        boolean perm = ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS)
                == PackageManager.PERMISSION_GRANTED;
        String u = getSharedPreferences("dz", Context.MODE_PRIVATE).getString("url", "");
        String s = "SMS permission: " + (perm ? "✅ granted" : "❌ NOT granted (tap allow)") + "\n";
        s += "Webhook URL: " + (u.isEmpty() ? "❌ not set" : "✅ saved") + "\n\n";
        s += (perm && !u.isEmpty())
                ? "✅ Ready. Keep this app installed. Every payment SMS is forwarded automatically."
                : "Grant permission + save the URL to start.";
        status.setText(s);
    }

    private void sendTest() {
        final String u = urlInput.getText().toString().trim();
        if (u.isEmpty()) { Toast.makeText(this, "Enter the URL first", Toast.LENGTH_SHORT).show(); return; }
        new Thread(new Runnable() {
            @Override public void run() {
                String msg;
                HttpURLConnection c = null;
                try {
                    JSONObject j = new JSONObject();
                    j.put("from", "bKash");
                    j.put("text", "You have received Tk 10.00 from 01700000000. TrxID TEST1234 Balance Tk 1. received");
                    byte[] body = j.toString().getBytes("UTF-8");
                    c = (HttpURLConnection) new URL(u).openConnection();
                    c.setRequestMethod("POST");
                    c.setConnectTimeout(12000); c.setReadTimeout(12000);
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                    OutputStream os = c.getOutputStream(); os.write(body); os.close();
                    int code = c.getResponseCode();
                    msg = code == 200 ? "✅ Server reachable (200). Setup works!" : "Server replied: " + code;
                } catch (Exception e) {
                    msg = "❌ Could not reach server: " + e.getMessage();
                } finally { if (c != null) c.disconnect(); }
                final String fm = msg;
                runOnUiThread(new Runnable() { @Override public void run() {
                    Toast.makeText(MainActivity.this, fm, Toast.LENGTH_LONG).show();
                }});
            }
        }).start();
    }

    @Override
    public void onRequestPermissionsResult(int rc, String[] p, int[] r) {
        super.onRequestPermissionsResult(rc, p, r);
        refresh();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
}
