# DizicarePay Forwarder (Android)

A tiny Android app that auto-forwards every incoming SMS to your Dizicare webhook URL.
The merchant just pastes their **Webhook URL** once — after that every bKash/Nagad/Rocket/Upay
payment SMS is sent to Dizicare automatically, so payments verify on their own.

## What it does
- Listens for incoming SMS in the background.
- POSTs `{ "from": "<sender>", "text": "<message>" }` as JSON to the saved URL.
- That is exactly what `api/pv-sms.php` expects.

## How to build the APK (one time, ~5 minutes)

**Option A — Android Studio (recommended)**
1. Install Android Studio (free): https://developer.android.com/studio
2. **File → Open** → select this `forwarder` folder. Let it sync (it downloads Gradle + SDK automatically).
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. The APK appears in `app/build/outputs/apk/debug/app-debug.apk`.

**Option B — command line** (if Android SDK is installed)
```
./gradlew assembleRelease
# or
gradle assembleRelease
```

## Install on the merchant's phone
1. Copy `app-debug.apk` to the Android phone that receives the payment SMS.
2. Tap it → allow "install from unknown sources" → Install.
3. Open **DizicarePay Forwarder**.
4. Allow the **SMS permission** when asked.
5. Paste the **Webhook URL** from the dashboard:
   - Merchant: `https://dizicare.site/api/pv-sms.php?key=YOUR_WEBHOOK_KEY`
   - Super admin (fee inbox): `https://dizicare.site/api/pv-sms.php?owner=dizicare&key=YOUR_KEY`
6. Tap **Save**, then **Send test to server** — you should see "✅ Server reachable (200)".

Done. Keep the app installed and the phone online. Every payment SMS now forwards automatically.

## Notes
- Android only. **iOS/iPhone cannot forward SMS** — Apple blocks SMS access for all apps.
  Use any Android phone (even a cheap spare) as the SMS gateway for the business number.
- Battery: on some phones, disable battery optimization for this app so it keeps running
  (Settings → Apps → DizicarePay Forwarder → Battery → Unrestricted).
- Package id: `site.dizicare.forwarder`. Change `applicationId` in `app/build.gradle` to rebrand.
