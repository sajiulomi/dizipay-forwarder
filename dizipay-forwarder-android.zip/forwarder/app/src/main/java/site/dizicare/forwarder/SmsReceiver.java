package site.dizicare.forwarder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * Receives every incoming SMS and forwards {from, text} to the saved webhook URL.
 */
public class SmsReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !"android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction())) return;

        SharedPreferences sp = context.getSharedPreferences("dz", Context.MODE_PRIVATE);
        final String url = sp.getString("url", "");
        if (url == null || url.trim().isEmpty()) return; // not configured yet

        Bundle bundle = intent.getExtras();
        if (bundle == null) return;

        // Re-assemble multipart SMS by sender
        Map<String, StringBuilder> bySender = new HashMap<>();
        try {
            Object[] pdus = (Object[]) bundle.get("pdus");
            String format = bundle.getString("format");
            if (pdus == null) return;
            for (Object pdu : pdus) {
                SmsMessage msg;
                if (format != null) msg = SmsMessage.createFromPdu((byte[]) pdu, format);
                else msg = SmsMessage.createFromPdu((byte[]) pdu);
                String from = msg.getOriginatingAddress();
                if (from == null) from = "unknown";
                StringBuilder sb = bySender.get(from);
                if (sb == null) { sb = new StringBuilder(); bySender.put(from, sb); }
                sb.append(msg.getMessageBody());
            }
        } catch (Exception e) {
            Log.e("DZ", "parse", e);
            return;
        }

        for (Map.Entry<String, StringBuilder> en : bySender.entrySet()) {
            post(url.trim(), en.getKey(), en.getValue().toString());
        }
    }

    private void post(final String url, final String from, final String text) {
        new Thread(new Runnable() {
            @Override public void run() {
                HttpURLConnection c = null;
                try {
                    JSONObject j = new JSONObject();
                    j.put("from", from);
                    j.put("text", text);
                    byte[] body = j.toString().getBytes("UTF-8");

                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setRequestMethod("POST");
                    c.setConnectTimeout(12000);
                    c.setReadTimeout(12000);
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                    OutputStream os = c.getOutputStream();
                    os.write(body); os.flush(); os.close();
                    int code = c.getResponseCode();
                    Log.d("DZ", "forwarded -> " + code);
                } catch (Exception e) {
                    Log.e("DZ", "post", e);
                } finally {
                    if (c != null) c.disconnect();
                }
            }
        }).start();
    }
}
